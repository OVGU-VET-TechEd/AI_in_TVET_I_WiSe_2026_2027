<!--
author:    Dr. Hannes Tegelbeckers
email:     hannes.tegelbeckers@ovgu.de
version:   1.1.1
language:  en
narrator:  UK English Female
mode:      Textbook

title:     S04 – Applications of AI in TVET: tools, agents, AI in pedagogy (Self-learning unit)
comment:   AI in TVET I – Self-learning unit for session 4 (live, 05.11.2026): adaptive learning, intelligent tutoring, chatbots, VR/AR, predictive analytics, curriculum alignment, AI in pedagogy and the micro-credential idea check.

import:    https://raw.githubusercontent.com/LiaTemplates/mermaid_template/0.1.4/README.md
-->

# S04 – Applications of AI in TVET

> **Session 4 · 05.11.2026 · 🟢 Live** – this unit accompanies the live session. Prepare sections 1–3 before the session; we work on section 5 (idea check) together.
>
> **Time needed:** about 90 minutes

**After this unit you will be able to …**

1. describe six application areas of AI in TVET with examples,
2. evaluate benefits and risks of an AI application for a specific vocational context,
3. explain how AI changes teaching, assessment and the teacher's role,
4. sharpen your micro-credential idea with a structured idea check.

## 1. Overview: Where AI Is Used in TVET

```mermaid @mermaid
flowchart TD
  LT(["Learner and Teacher"]):::human
  LT --- A["Adaptive<br>learning systems"]:::sys
  LT --- B["Intelligent<br>tutoring systems"]:::sys
  LT --- C["Chatbots /<br>AI assistants"]:::sys
  LT --- D["VR/AR +<br>AI simulation"]:::sys
  LT --- E["Predictive<br>analytics"]:::sys
  LT --- F["Curriculum<br>alignment"]:::sys
  classDef sys fill:#f7eef2,stroke:#7a003f,stroke-width:1.5px,color:#1f1f1f
  classDef human fill:#ffffff,stroke:#d03b3b,stroke-width:3px,color:#1f1f1f
```

| Application | What it does | Example in TVET |
| --- | --- | --- |
| Adaptive learning systems (ALS) | Adjust content, pace and difficulty to the learner | Online module on hydraulics that offers extra exercises after errors |
| Intelligent tutoring systems (ITS) | Simulate one-to-one tutoring with step-by-step feedback | Tutor guiding through a fault-finding task in electrical installation |
| Chatbots / AI assistants | Answer questions 24/7, support administration and learning | Course chatbot answering questions about workshop safety rules |
| VR/AR with AI | Practise skills in simulated environments with automatic feedback | Welding simulator analysing torch angle and speed |
| Predictive analytics | Identify learners at risk early | Early-warning dashboard for dropout risk |
| Curriculum alignment | Analyse labour-market data to update curricula | Matching job advertisements with training regulations |

## 2. The Applications in Detail

The following pages look at the six application areas one by one. For each, ask yourself three questions while reading: *What does the system decide or suggest? Which data does it need? What remains the task of the teacher or trainer?* You will use these questions again in section 3 to evaluate an application.

### 2.1 Adaptive learning systems

Adaptive systems use a learner model (what the learner knows) and a domain model (what there is to learn) to choose the next step.

- **Evidence:** A scoping review of 69 studies in higher education found improved academic performance in 41 studies (59 %) and higher engagement in 25 (36 %). Pre-knowledge quizzes were the most common trigger for adaptive content; Moodle was among the most used platforms (du Plooy et al., 2024).
- **Still few real systems:** A mapping of 147 studies (2014–2020) shows many prototypes but a low number of implemented systems that address learners' actual problems (Kabudi et al., 2021). Publications on AI-driven adaptive learning rose from 1 in 1990 to 636 in 2023 (Strielkowski et al., 2025).
- **The teacher as conductor:** Observations in vocational classrooms show that good vocational teachers *orchestrate* lessons: small-group collaboration, tasks linked to real work situations, adaptive and structured instructions, flexible arrangements (Zhao & Ko, 2024). Adaptive software has to fit into this orchestration – not replace it.

**Risks:** biased learner models, high costs, data protection, "learning in isolation".

### 2.2 Intelligent tutoring systems

ITS give hints and feedback at each step of a task. A systematic review of 40 field studies (2011–2022) found a **complicated picture** rather than clear success: most studies come from a few countries ("intelligent regional gap"), they focus on test performance rather than motivation, learning processes or social outcomes, and some lack scientific rigour (Wang et al., 2023).

Most ITS support individual learners only. Arnau-González et al. (2025) present an open-source framework that turns individual conversational tutors into **collaborative** ones without noticeable loss of speed.

### 2.3 Chatbots and AI assistants

Chatbots support learners and staff with quick, personalised answers – a review of 53 studies summarises benefits, challenges and open research questions (Okonkwo & Ade-Ibijola, 2021). A design model for school chatbots shows that they can also connect learners with teachers, social workers and psychologists and help less tech-savvy users through a familiar chat environment (Mendoza et al., 2022).

Whether teachers adopt chatbots depends on **innovativeness**, **trust** in the chatbot's privacy and pedagogical reliability, perceived ease of use – and on **social pressure from colleagues and school leaders** (survey of 482 teachers; Celik et al., 2025).

### 2.4 VR/AR and AI in skill training

Conventional welding training is costly in material, time and infrastructure. VR/AR simulators (e.g. from Fronius, MIMBUS, Seabery) allow safe, material-saving practice and train concentration and accuracy (Lavrentieva et al., 2020). A review of 42 studies (2000–2021) classifies their functions, but finds that most studies target **entry-level** learners and there is little evidence on distance learning (Chan et al., 2022). **Limits:** costs, cybersickness, transfer to the real workshop must be checked.

### 2.5 Predictive analytics

- **The imbalance problem:** With 14,495 students and a dropout rate of 8.5 %, a standard classifier recognised only **13 %** of the dropouts – while being 99 % right on those who stayed. Only after adjusting the decision threshold did dropout precision exceed 50 % (Gonzalez-Nucamendi et al., 2023). High "accuracy" can hide a useless early-warning system.
- **In vocational schools:** At a large vocational and technical high school in Istanbul, a decision tree with oversampling identified at-risk students best; parental education, family structure and financial hardship were strong predictors (Korkmaz & Aydın, 2025).

**Remember S02:** predictors such as family background are exactly where bias and stigmatisation start. Such systems can be high-risk under the EU AI Act.

### 2.6 Curriculum alignment with labour-market data

AI can analyse labour-market data to identify emerging skills and help adapt curricula faster (Ejjami, 2024). The **3E model** links three pillars – *education* (AI curriculum design), *experience* (VR training) and *employment* (industry partnerships with AI-based labour-market scans) – and was tested with 10 vocational schools and 15 industry partners (Liao & Zheng, 2025).

**But:** An integrative review warns that unequal access and biased algorithms can **widen inequalities** in vocational training. It calls for investment in infrastructure, continuous teacher training and new roles such as a *Vocational AI Curriculum Developer* or *AI Data Protection Specialist* (Ejjami, 2024).

**Check:** Which application gives step-by-step hints while a learner solves a task?

- [( )] Predictive analytics
- [(X)] Intelligent tutoring system
- [( )] Curriculum alignment tool

## 3. Evaluating an AI Application

Use this grid whenever you assess an AI tool for teaching:

| Criterion | Questions |
| --- | --- |
| **Pedagogical value** | Which learning outcome does it support? Is there evidence? |
| **Learner role** | Does it promote active learning or passive consumption? |
| **Teacher role** | Who decides? Can the teacher adapt or override? |
| **Data & privacy** | Which data is collected, where is it stored, GDPR? |
| **Fairness & inclusion** | Does it work for all learners (language, disability, devices)? |
| **Legal frame** | Risk level under the EU AI Act? Licence? |
| **Costs & sustainability** | Costs, maintenance, energy, dependency on a provider |

**Task (before the session, 20 min):** Choose one application from section 1 for your vocational field and fill in the grid. Bring it to the live session.

## 4. AI in Pedagogy

AI changes not only tools but teaching itself.

{{1}}
<section>

**1. Personalisation** – individual learning paths and feedback, especially in heterogeneous groups.

**2. New teacher roles** – from knowledge transmitter to learning designer, coach and critical curator of AI output. Teachers need knowledge that combines technology, pedagogy and content: **AI-TPACK** (Ning et al., 2024).

**3. Feedback and self-regulation** – AI can support goal setting, monitoring and reflection (Chang et al., 2023), but learners can also offload thinking to the tool.

**4. Assessment** – AI can generate tasks and give formative feedback; summative decisions remain with humans (see S02).

**5. Inclusion** – translation, simplified language and assistive features – if access is fair.

**6. Self-determined learning (heutagogy)** – learners take control of their learning path, even of goals and assessment. Ng and Lai (2025) link three AI paradigms to rising autonomy and the SOLO levels of understanding:

| AI paradigm | Role of AI | SOLO level | Learner autonomy |
| --- | --- | --- | --- |
| **AI-informed** | Provides information and progress data | Pre-/uni-structural | Low – teachers guide strongly |
| **AI-supported** | Adaptive feedback, tailored content | Multi-structural, relational | Growing |
| **AI-empowered** | Partner for open, complex problems | Extended abstract | Full autonomy and agency |

For TVET this fits continuing education and master-craftsperson training, where adults steer their own learning. The authors stress that it needs deliberate changes to pedagogy and assessment, staff development and infrastructure.

</section>

**Discussion question for the session:** Which of these six changes is most relevant for your vocational field – and what would you need as a teacher to handle it?

## 5. Micro-credential Idea Check (live)

Your final product is a **TVET micro-credential** with AI-supported LiaScript learning nuggets. In the live session we check your idea from the S03 hand-in with these questions:

| # | Question | Your answer |
| --- | --- | --- |
| 1 | Which **skill gap** in which TVET sector do you address? | |
| 2 | Who is the **target group** (apprentices, teachers, in-company trainers, adult learners)? | |
| 3 | Which **UNESCO competency** (Students or Teachers framework) is the anchor? | |
| 4 | What are 2–3 **learning outcomes** (verb + content + context)? | |
| 5 | Which **3–6 nuggets** could the micro-credential have? | |
| 6 | How do learners **prove** the outcome (assessment)? | |
| 7 | Where does **AI** support learning – and where is it deliberately not used? | |
| 8 | Why would a **TVET institution or employer** recognise it? | |

**Feedback rule in the session:** each idea gets one "What works" and one "What if …?" from peers.

## 6. Preparation for Session 5

Next session (12.11.2026, 🔵 self-learning) you learn how to describe your micro-credential with the **EU template** and start your learning nuggets. Revise your idea with the feedback from today.

## References

- Arnau-González, P., Solera-Monforte, S., Wu, Y., & Arevalillo-Herráez, M. (2025). A framework for adapting conversational intelligent tutoring systems to enable collaborative learning. *Expert Systems with Applications, 271*, 126663. https://doi.org/10.1016/j.eswa.2025.126663
- Celik, I., Muukkonen, H., & Siklander, S. (2025). Teacher – artificial intelligence (AI) interaction: The role of trust, subjective norm and innovativeness in teachers’ acceptance of educational chatbots. *Policy Futures in Education, 24*(1), 164–188. https://doi.org/10.1177/14782103251348551
- Chan, V. S., Haron, H. N. H., Isham, M. I. B. M., & Mohamed, F. B. (2022). VR and AR virtual welding for psychomotor skills: A systematic review. *Multimedia Tools and Applications, 81*, 12459–12493. https://doi.org/10.1007/s11042-022-12293-5
- Chang, D. H., Lin, M. P.-C., Hajian, S., & Wang, Q. Q. (2023). Educational design principles of using AI chatbot that supports self-regulated learning in education: Goal setting, feedback, and personalization. *Sustainability, 15*(17), 12921. https://doi.org/10.3390/su151712921
- du Plooy, E., Casteleijn, D., & Franzsen, D. (2024). Personalized adaptive learning in higher education: A scoping review of key characteristics and impact on academic performance and engagement. *Heliyon, 10*(21), e39630. https://doi.org/10.1016/j.heliyon.2024.e39630
- Ejjami, R. (2024). AI’s impact on vocational training and employability: Innovation, challenges, and perspectives. *International Journal for Multidisciplinary Research, 6*(4). https://doi.org/10.36948/ijfmr.2024.v06i04.24967
- Gonzalez-Nucamendi, A., Noguez, J., Neri, L., Robledo-Rella, V., & García-Castelán, R. M. G. (2023). Predictive analytics study to determine undergraduate students at risk of dropout. *Frontiers in Education, 8*, 1244686. https://doi.org/10.3389/feduc.2023.1244686
- Korkmaz, Ö., & Aydın, M. N. (2025). Detection of early school drop out in vocational and technical high schools in Turkey. *SAGE Open, 15*(3). https://doi.org/10.1177/21582440251370443
- Kabudi, T., Pappas, I., & Olsen, D. H. (2021). AI-enabled adaptive learning systems: A systematic mapping of the literature. *Computers and Education: Artificial Intelligence, 2*, 100017. https://doi.org/10.1016/j.caeai.2021.100017
- Lavrentieva, O. O., Arkhypov, I. O., Kuchma, O. I., & Uchitel, A. D. (2020). Use of simulators together with virtual and augmented reality in the system of welders’ vocational training: Past, present, and future. *CEUR Workshop Proceedings, 2547*, 201–216. https://ceur-ws.org/Vol-2547/paper15.pdf
- Liao, J., & Zheng, Y. (2025). Integrating artificial intelligence into vocational education: A technical application framework based on the 3E model. In *Proceedings of the 2nd Guangdong-Hong Kong-Macao Greater Bay Area International Conference on Digital Economy and Artificial Intelligence* (pp. 1489–1493). ACM. https://doi.org/10.1145/3745238.3745471
- Mendoza, S., Sánchez-Adame, L. M., Urquiza-Yllescas, J. F., González-Beltrán, B. A., & Decouchant, D. (2022). A model to develop chatbots for assisting the teaching and learning process. *Sensors, 22*(15), 5532. https://doi.org/10.3390/s22155532
- Ng, S. H. S., & Lai, J. W. (2025). AI-augmented heutagogy: A framework for fostering self-determined learning and agency in higher education. *Higher Education Research & Development*. Advance online publication. https://doi.org/10.1080/07294360.2025.2564977
- Ning, Y., Zhang, C., Xu, B., Zhou, Y., & Wijaya, T. T. (2024). Teachers’ AI-TPACK: Exploring the relationship between knowledge elements. *Sustainability, 16*(3), 978. https://doi.org/10.3390/su16030978
- Okonkwo, C. W., & Ade-Ibijola, A. (2021). Chatbots applications in education: A systematic review. *Computers and Education: Artificial Intelligence, 2*, 100033. https://doi.org/10.1016/j.caeai.2021.100033
- Strielkowski, W., Grebennikova, V., Lisovskiy, A., Rakhimova, G., & Vasileva, T. (2025). AI-driven adaptive learning for sustainable educational transformation. *Sustainable Development, 33*, 1921–1947. https://doi.org/10.1002/sd.3221
- Wang, H., Tlili, A., Huang, R., Cai, Z., Li, M., Cheng, Z., Yang, D., Li, M., Zhu, X., & Fei, C. (2023). Examining the applications of intelligent tutoring systems in real educational contexts: A systematic literature review from the social experiment perspective. *Education and Information Technologies, 28*(7), 9113–9148. https://doi.org/10.1007/s10639-022-11555-x
- Zhao, Y., & Ko, J. (2024). Orchestrating vocational education classrooms for adaptive instruction and collaborative learning. *Cogent Education, 11*(1). https://doi.org/10.1080/2331186X.2024.2351238

<small>Licence: CC BY 4.0 · Dr. Hannes Tegelbeckers, OVGU Magdeburg · Created with AI support (Claude), checked and revised by the author.</small>
